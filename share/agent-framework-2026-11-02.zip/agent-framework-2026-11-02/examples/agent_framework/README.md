# 합성 에이전트 계약 예제

이 폴더의 JSON은 실제 PDF, 포스터, 모델, PostgreSQL, Neo4j 실행 결과가 아닙니다.
파일 ID와 SHA-256도 **합성 참조 문자열**을 나타냅니다. 원본 미디어 파일은 제공하지 않습니다.
모든 역할 출력의 `synthetic`은 `true`이며 모델 정확도나 배포 완료 증거로 사용할 수 없습니다.

| 역할 | 요청 JSON | 응답 JSON | 계약 |
|---|---|---|---|
| A02 조건 추출 | `A02.json` | `A02.output.json` | ExtractRequest → CriteriaDraft |
| A03 근거 검색 | `A03.json` | `A03.output.json` | RetrieveRequest → EvidenceBundle |
| A04/A05 통합 검사 | `A04_A05.json` | `A04_A05.output.json` | InspectRequest → InspectionResult |
| A06 코드 검증 | `A06.json` | `A06.output.json` | ValidateRequest → ValidatedResult |
| A07 보고서 | `A07.json` | `A07.output.json` | ReportRequest → ReportDraft |

기본 예제는 `MORNING CUP` 정확문구와 딸기 `3개` 조건을 사용합니다.
`scenarios/`에는 `pass`, `fail`, `review`, `stale`, `unavailable`의 A06 검증 결과가 있습니다.
`stale`과 `unavailable`에서는 합성 검사기가 충족을 주장해도 검색 근거가 불완전하므로 코드 검증이 `review`로 남깁니다.

저장소 루트에서 같은 JSON을 다시 생성할 수 있습니다. 외부 서비스에 접속하지 않습니다.

```sh
python -m backend.agent_framework.adapters.generate_examples
```

`custom_adapter.py`는 팀별 어댑터 팩터리의 연결 위치만 보여 줍니다. 구현하지 않은 메서드는
`ADAPTER_NOT_CONFIGURED`를 반환하며 합성 결과로 대체하지 않습니다. 실제 서비스를 연결할 때는
각 메서드의 입력·출력 계약과 현재 버전·출처·인용 검증을 유지해야 합니다.

## 팀별 역할 설정

- `team_config.template.json`: A02·A03·A04_A05·A07은 미설정, A06은 참조 검증기입니다. 팀 연결용으로 복사해 사용합니다.
- `team_config.synthetic.json`: 합성 역할과 A06 참조 검증기를 명시적으로 조합합니다. 실제 모델·DB 연결을 하지 않습니다.
- `team_adapters.py`: 역할별 `create_extractor`, `create_retriever`, `create_inspector`, `create_validator`, `create_reporter` factory의 시작점입니다. 모델·검색 stub은 호출 시 `ADAPTER_NOT_CONFIGURED`로 실패합니다.

설정 파일에는 다섯 역할을 모두 선언하고, 역할 하나의 binding을 다음처럼 바꿉니다. 아래는 `roles.A03`의 값이며 완전한 설정 파일이 아닙니다.

```json
{
  "kind": "factory",
  "factory": "examples.agent_framework.team_adapters:create_retriever"
}
```

역할별 factory는 인자 없이 **단일 역할 어댑터**를 반환합니다. 기존 `custom_adapter:make_agents`와 CLI의 `--factory`는 `Agents` 전체를 반환하는 별도 경로로 유지됩니다. factory import·생성자는 부작용 없이 작성하고, 클라이언트는 역할 메서드에서 필요할 때 초기화합니다. 여러 실행이 인스턴스를 공유할 수 있으므로 클라이언트 초기화·호출 동시 접근도 담당자가 관리합니다. 미구현·연결 실패를 합성 데이터로 대체하지 않습니다.

macOS:

```sh
.venv/bin/python -m backend.agent_framework doctor --config examples/agent_framework/team_config.synthetic.json
.venv/bin/python -m backend.agent_framework role A03 --input examples/agent_framework/A03.json --config examples/agent_framework/team_config.synthetic.json
.venv/bin/python -m backend.agent_framework serve --config examples/agent_framework/team_config.synthetic.json --port 8012
```

Windows PowerShell에서는 위의 실행 파일을 `.\.venv\Scripts\python.exe`로 바꾸고 동일한 인자를 사용합니다.

`doctor`는 설정 검사·설명만 하며 설정된 모듈의 import, factory·역할 호출, 접속 검증은 하지 않습니다. `role --config`는 선택한 역할만 생성합니다. `serve --config`는 동일 구성으로 개발 API를 열며 loopback `127.0.0.1`, 단일 worker, 인증 없음, 메모리 저장 범위입니다. 시작만으로 검수·승인을 실행하지 않습니다. `GET /api/framework/v1/configuration`에서 구성 선언과 초기화 상태를 확인할 수 있으며 실제 연결 검증은 별개입니다.

공통 CLI·실행기 호출은 같은 계약 검증을 적용하고 중첩 합성 입력의 표시를 결과까지 유지합니다. 자세한 소유 범위·계약 규칙은 [개발 가이드](../../docs/agent-framework/README.md)를 따릅니다. 개발 정본은 루트 `backend/agent_framework`, `docs/agent-framework`, `tests/agent_framework`이며 `share/에이전트_흐름도`는 수정 대상이 아닌 배포 사본입니다.
