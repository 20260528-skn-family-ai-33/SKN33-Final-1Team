# Creative Checker — Graphify AST audit

> **Static code relationships only.** This graph does not demonstrate real Qwen execution,
> PostgreSQL/Neo4j connectivity, durable workers, or production deployment.
> The separate clickable business flow is a curated workflow illustration, not this AST graph.

- Tool: official `graphifyy==0.9.100`; directed build, community detection and native HTML exporter.
- Corpus: **14 Python files**, 6,598 words, exclusively `backend/agent_framework/**/*.py`.
- Git baseline: `2e2ed74f227474463b5e4c2e4ed9d2fa2aa0eba0`. The files are current working-tree sources; their SHA-256 values are recorded in `source-manifest.json`.
- Raw AST: **209 nodes / 860 edges**.
- Native directed graph: **225 nodes / 804 edges / 8 communities**.
- **Integrity limits:** raw dangling endpoints 50, missing endpoints 0, self-loops 1, same-endpoint directed edges collapsed 56.
- Build added **16 implicit/external placeholder nodes**. These have no extracted in-scope definition; they are not deployment components.
- The native view has collapsed parallel relations. **`extraction.json` retains every raw relationship and source location**; `diagnostics.json` and `diagnostics.txt` retain the official diagnostic.
- Raw edge confidence: `{'EXTRACTED': 719, 'INFERRED': 141}`. `INFERRED` edges are extractor resolution inferences, not verified runtime calls.
- Source direction, confidence, `_origin` and location metadata are retained as emitted by Graphify. AST name resolution can be incomplete or ambiguous.
- AST extraction model tokens: **0 input / 0 output**. No semantic extraction or model API call. Host-agent reasoning/labeling tokens were **not separately measured**; this is not a zero-cost claim for the whole conversation.
- Token-reduction benchmark not run: the requested scope is the flow/code graph artifact, not a compression experiment.
- `graph.html` uses the official renderer with only its pinned vis-network dependency embedded after SRI verification. **No automatic external HTML resources remain in a static audit. Browser rendering was not tested here.**
- Graphify detected this small corpus as fitting in one context; graph generation proceeded because the user explicitly requested it.
- Rebuild script: `scripts/build_agent_code_graph.py`. A disposable environment and asset cache are required; project dependencies and user profiles were not changed.
- These outputs are written into the working tree; no ignore, commit or push operation was performed.

- Portable sharing: source metadata uses repository-relative paths; the extractor path is package-relative. Nodes, edges and diagnostic counts are unchanged.

## Raw diagnostic

```text
[graphify] MultiDiGraph edge-collapse diagnostic
input: <in-memory>
input_stage: provided JSON (normal graph.json is post-build)
effective_directed: <direct-call>
nodes: 209
unverified_code_nodes: 0
raw_edges: 860
valid_candidate_edges: 810
missing_endpoint_edges: 0
dangling_endpoint_edges: 50
external_reference_edges: 0
self_loop_edges: 1
exact_duplicate_edges: 0
directed_unique_endpoint_pairs: 754
directed_same_endpoint_collapsed_edges: 56
undirected_unique_endpoint_pairs: 754
undirected_same_endpoint_collapsed_edges: 56
same_endpoint_group_count: 51
relation_variant_groups: 46
source_file_variant_groups: 0
source_location_variant_groups: 0
context_variant_groups: 5
post_build_graph_type: DiGraph
post_build_edges: 804
producer_suppression_sites: 12
producer_suppression_examples:
  - L1830 seen_ids arity=unknown
  - L2393 seen_ids arity=unknown
  - L2395 seen_doc_refs arity=unknown
  - L3062 seen_ids arity=unknown
  - L3209 seen_ids arity=unknown
  - L4350 seen_keys arity=unknown
  - L4536 seen_keys arity=unknown
  - L8160 seen_ids arity=unknown
examples:
  - adapters_synthetic_sample_inputs -> contracts_context edges=3 relations=['calls', 'references', 'uses'] locations=['L30', 'L34', 'L36'] contexts=['', 'call', 'generic_arg']
  - adapters_synthetic_sample_inputs -> contracts_documentref edges=3 relations=['calls', 'references', 'uses'] locations=['L30', 'L34', 'L41'] contexts=['', 'call', 'generic_arg']
  - adapters_synthetic_sample_inputs -> contracts_assetref edges=3 relations=['calls', 'references', 'uses'] locations=['L30', 'L34', 'L45'] contexts=['', 'call', 'generic_arg']
  - adapters_synthetic_make_agents -> ports_agents edges=3 relations=['calls', 'references', 'uses'] locations=['L174', 'L179'] contexts=['', 'call', 'return_type']
  - composition_build_agents -> ports_agents edges=3 relations=['calls', 'references', 'uses'] locations=['L170', 'L173'] contexts=['', 'call', 'return_type']
note: normal graph.json is post-build; raw producer loss must be measured earlier.
```

---

# Graph Report - agent_framework  (2026-11-02)

## Corpus Check
- Corpus is ~6,598 words - fits in a single context window. You may not need a graph.

## Summary
- 225 nodes · 804 edges · 8 communities (6 shown, 2 thin omitted)
- Extraction: 86% EXTRACTED · 14% INFERRED · 0% AMBIGUOUS · INFERRED: 113 edges (avg confidence: 0.93)
- Token cost: 0 input · 0 output

## Graph Freshness
- Built from commit: `2e2ed74f`
- Run `git rev-parse HEAD` and compare to check if the graph is stale.
- Run `graphify update .` after code changes (no API cost).

## Community Hubs (Navigation)
- Synthetic data and observations
- CLI and fixture composition
- Workflow and human approvals
- Cli relationships
- Validation relationships
- Evidence and verdict validation

## God Nodes (most connected - your core abstractions)
1. `Workflow` - 38 edges
2. `AdapterFailure` - 31 edges
3. `SyntheticAdapters` - 26 edges
4. `Contract` - 26 edges
5. `create_app()` - 22 edges
6. `InspectRequest` - 22 edges
7. `RetrieveRequest` - 20 edges
8. `ReportRequest` - 19 edges
9. `invoke_role()` - 19 edges
10. `ValidateRequest` - 18 edges

## Surprising Connections (you probably didn't know these)
- `_same_context()` --uses--> `Context`  [INFERRED]
  adapters/synthetic.py → contracts.py
- `SyntheticAdapters` --uses--> `AdapterFailure`  [INFERRED]
  adapters/synthetic.py → ports.py
- `QwenAdapterStub` --uses--> `AdapterFailure`  [INFERRED]
  adapters/templates.py → ports.py
- `PostgresNeo4jRetrieverStub` --uses--> `EvidenceBundle`  [INFERRED]
  adapters/templates.py → contracts.py
- `PostgresNeo4jRetrieverStub` --uses--> `RetrieveRequest`  [INFERRED]
  adapters/templates.py → contracts.py

## Import Cycles
- None detected.

## Communities (8 total, 2 thin omitted)

### Community 0 - "Synthetic data and observations"
Cohesion: 0.11
Nodes (22): _hash(), _same_context(), SyntheticAdapters, source(), QwenAdapterStub, CriteriaDraft, Criterion, Evidence (+14 more)

### Community 1 - "CLI and fixture composition"
Cohesion: 0.08
Nodes (28): PostgresNeo4jRetrieverStub, create_app(), adapter_status(), approve(), configuration_status(), health(), invoke(), read() (+20 more)

### Community 2 - "Workflow and human approvals"
Cohesion: 0.15
Nodes (16): sample_inputs(), RevisionRequest, StartRequest, _demo(), Approval, AssetRef, Context, Contract (+8 more)

### Community 3 - "Cli relationships"
Cohesion: 0.10
Nodes (17): generate(), main(), role_examples(), make_agents(), _ConfigError, _doctor(), _emit(), _error() (+9 more)

### Community 4 - "Validation relationships"
Cohesion: 0.23
Nodes (16): _contract(), _input_policy(), invoke_role(), _output_policy(), _policy(), _reject(), _synthetic(), aggregate() (+8 more)

### Community 5 - "Evidence and verdict validation"
Cohesion: 0.29
Nodes (7): _SyntheticValidator, RoleRequest, ValidatedItem, ValidatedResult, ValidateRequest, Validator, ReferenceValidator

## Knowledge Gaps
- **2 thin communities (<3 nodes) omitted from report** — run `graphify query` to explore isolated nodes.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **Why does `SyntheticAdapters` connect `Synthetic data and observations` to `CLI and fixture composition`, `Cli relationships`?**
  _High betweenness centrality (0.013) - this node is a cross-community bridge._
- **Are the 15 inferred relationships involving `Workflow` (e.g. with `Approval` and `AssetRef`) actually correct?**
  _`Workflow` has 15 INFERRED edges - model-reasoned connections that need verification._
- **Should `Synthetic data and observations` be split into smaller, more focused modules?**
  _Cohesion score 0.1085972850678733 - nodes in this community are weakly interconnected._
- **Why does `Workflow` connect `Workflow and human approvals` to `Synthetic data and observations`, `CLI and fixture composition`, `Cli relationships`, `Evidence and verdict validation`?**
  _High betweenness centrality (0.009) - this node is a cross-community bridge._
- **Are the 14 inferred relationships involving `SyntheticAdapters` (e.g. with `CriteriaDraft` and `Criterion`) actually correct?**
  _`SyntheticAdapters` has 14 INFERRED edges - model-reasoned connections that need verification._
- **Should `CLI and fixture composition` be split into smaller, more focused modules?**
  _Cohesion score 0.0841813135985199 - nodes in this community are weakly interconnected._
- **Why does `invoke_role()` connect `Validation relationships` to `CLI and fixture composition`?**
  _High betweenness centrality (0.008) - this node is a cross-community bridge._